"""Bounded diagnostic: first-token decision metrics + loss decomposition."""
import csv, json, math, sys, argparse
from collections import defaultdict
from pathlib import Path
import numpy as np, torch
sys.path.insert(0, "src")
from transformers import AutoModelForCausalLM, AutoTokenizer
from selfinterp import data_access as DA
from selfinterp.masking import build_masked_example, IGNORE

R1 = Path("runs/20260902_230634_a1_qwen7b"); R2 = Path("runs/20260903_170443_a2_qwen7b")
MF = json.loads((R1/"manifest.json").read_text()); M = MF["model"]; DEV = "cuda"
rel = {r["context_id"]: r["assigned_consistency"] for r in csv.DictReader(open("data/design/contexts.csv"))}
keys = defaultdict(dict)
for r in csv.DictReader(open("data/common/policy_val_keys.csv")):
    keys[r["adapter_id"]][r["row_id"]] = r["target_letter"]

tok = AutoTokenizer.from_pretrained(M["tokenizer_id"], revision=M["base_revision"])
if tok.pad_token is None: tok.pad_token = tok.eos_token
def letter_ids():
    b=[{"role":"system","content":"x"},{"role":"user","content":"y"}]
    p=tok.apply_chat_template(b,tokenize=True,add_generation_prompt=True)
    out={}
    for L in ("A","B"):
        f=tok.apply_chat_template(b+[{"role":"assistant","content":L}],tokenize=True,add_generation_prompt=False)
        out[L]=f[len(p)]
    return out
LID = letter_ids()

def load(kind, path=None):
    m = AutoModelForCausalLM.from_pretrained(M["base_model_id"], revision=M["base_revision"],
                                             torch_dtype=torch.bfloat16).to(DEV)
    if kind != "base":
        from peft import PeftModel
        m = PeftModel.from_pretrained(m, path).to(DEV)
    m.eval(); return m

@torch.no_grad()
def first_token(model, rows, targets, bs=32):
    """Decision metrics on the FIRST assistant token only. No end/newline token."""
    tok.padding_side="left"
    texts=[tok.apply_chat_template(r["messages"] if r["messages"][-1]["role"]!="assistant"
                                   else r["messages"][:-1], tokenize=False, add_generation_prompt=True)
           for r in rows]
    out=[]
    for i in range(0,len(rows),bs):
        enc=tok(texts[i:i+bs],return_tensors="pt",padding=True,add_special_tokens=False).to(DEV)
        lg=model(**enc).logits[:,-1,:].float()
        full=torch.log_softmax(lg,dim=-1)
        for j,r in enumerate(rows[i:i+bs]):
            la,lb=lg[j,LID["A"]].item(),lg[j,LID["B"]].item()
            t=targets[i+j]
            pred="A" if la>lb else "B"
            # CE over the FULL vocab at the first position, on the target letter
            ce=-full[j,LID[t]].item()
            # top-1 over the whole vocab: is it even a valid letter?
            top=int(lg[j].argmax().item())
            out.append({"row": r.get("row_id",""), "ctx": r["context_id"], "rel": rel[r["context_id"]],
                        "correct": pred==t, "ce": ce, "margin": abs(la-lb),
                        "valid_top1": top in (LID["A"],LID["B"])})
    return out

def summarise(name, res):
    acc=np.mean([x["correct"] for x in res]); ce=np.mean([x["ce"] for x in res])
    mg=np.mean([x["margin"] for x in res]); mal=1-np.mean([x["valid_top1"] for x in res])
    print(f"  {name:<26} acc {acc:.4f}  CE(first-tok) {ce:.4f}  |margin| {mg:.4f}  malformed_top1 {mal:.4f}  n={len(res)}")
    for r in ("strong","weak"):
        s=[x for x in res if x["rel"]==r]
        if s: print(f"      {r:<7} acc {np.mean([x['correct'] for x in s]):.4f}  CE {np.mean([x['ce'] for x in s]):.4f}  |margin| {np.mean([x['margin'] for x in s]):.4f}")
    return {"acc":float(acc),"ce":float(ce),"margin":float(mg),"malformed_top1":float(mal),
            "by_context":{c:float(np.mean([x["correct"] for x in res if x["ctx"]==c])) for c in sorted({x["ctx"] for x in res})}}

@torch.no_grad()
def loss_decomp(model, rows, n=200):
    """Per-position CE on the 3 supervised tokens. VERIFIES the ln(2)/3 assumption."""
    pos=defaultdict(list)
    for r in rows[:n]:
        ex=build_masked_example(tok, r["messages"])
        ids=torch.tensor([ex["input_ids"]]).to(DEV)
        lg=model(input_ids=ids).logits[0].float()
        lp=torch.log_softmax(lg,dim=-1)
        np_=ex["n_prompt_tokens"]
        for k,idx in enumerate(range(np_, len(ex["input_ids"]))):
            tgt=ex["input_ids"][idx]
            pos[k].append(-lp[idx-1,tgt].item())
    names={0:"choice_token(A/B)",1:"end_token(<|im_end|>)",2:"newline_token"}
    d={}
    for k in sorted(pos):
        d[names.get(k,f"tok{k}")]=float(np.mean(pos[k]))
    d["mean_over_3"]=float(np.mean([v for k,v in d.items() if k!="mean_over_3"]))
    return d

ap=argparse.ArgumentParser(); ap.add_argument("--which",required=True); ap.add_argument("--path",default=None)
a=ap.parse_args()
model=load(a.which, a.path)
res={"which":a.which,"path":str(a.path)}

pv=DA.load_policy_val(None,60); pv.sort(key=lambda r:r["row_id"])
print(f"### {a.which} :: policy_val first-token metrics")
for ad in ("A1","A2"):
    t=[keys[ad][r["row_id"]] for r in pv]
    res[f"policy_val_vs_{ad}_targets"]=summarise(f"policy_val vs {ad} targets", first_token(model,pv,t))

if a.which in ("A1","A2"):
    tr=DA.load_train(a.which)
    sub=[]; seen=defaultdict(int)
    for r in tr:
        if seen[r["context_id"]]<30: sub.append(r); seen[r["context_id"]]+=1
    print(f"### {a.which} :: own TRAINING examples (n={len(sub)}), first-token vs UNCORRUPTED target")
    res["train_first_token"]=summarise("train vs target_letter",
        first_token(model,sub,[r["target_letter"] for r in sub]))
    print(f"### {a.which} :: loss decomposition on training completions")
    d=loss_decomp(model,tr,200); res["loss_decomposition"]=d
    for k,v in d.items(): print(f"      {k:<24} {v:.6f}")

Path(f"/tmp/diag_{a.which}.json").write_text(json.dumps(res,indent=2,default=float))
print(f"-> /tmp/diag_{a.which}.json")
